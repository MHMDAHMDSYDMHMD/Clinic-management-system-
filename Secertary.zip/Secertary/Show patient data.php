<?php
$Database = new mysqli("localhost","root", "", "clinic_management_system");
?>

<!DOCTYPE html>
<html lang="en">
<head>    
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap 5.css">
    <script src="bootstrap 5.js" ></script>
    <!-- <script src="bootstrap 5.1.js" ></script>
    <script src="bootstrap 5.2.js" ></script> -->
    <title>Patient data</title>
</head>
<body>
  <header>
    <div> 
      <ul>
        <li><img src="IMRA-1 (6).png" alt=""></li>
        <a href="Home Admin.html"><li class="title">home</li></a>
        <a href="Add Patient Page.html"><li class="title">Add Patient</li></a>
        <a href="reservation page.html"><li class="title">Reserve</li></a>
        <li class="title">
          <p class="title" class="dropdown-toggle" data-bs-toggle="dropdown">Register</p>
          <ul class="dropdown-menu">
            <li class="li"><a class="dropdown-item" href="the login page/index.html">Login</a></li>
            <li class="li"><a class="dropdown-item" href="the sign up\index.html">sign ip</a></li>
          </ul>
        </li>
        <li class="title">
          <p class="title" class="dropdown-toggle" data-bs-toggle="dropdown">Show</p>
          <ul class="dropdown-menu">
            <li class="li"><a class="dropdown-item" href="show data page.html">Patient Data</a></li>
            <li class="li"><a class="dropdown-item" href="show docter data page.html">Docters Data</a></li>
          </ul>
        </li>
      </ul>  
    </div>  
  </header>

  <div class="div2">
    <div>
      <h1>Show Patient Data</h1>
      <form method="POST">
        <input type="text" placeholder="search about patient">
        <!-- <button type="button" name="send" class="but">
            <img src="PFP.jpg" alt="">
        </button> -->
      </form>
    </div>
  </div>

  <div id="DIV">  
    
    <!-- <div class="div3">
        <table>
          <tr>
            <th>name</th>
            <td>lksdjf</td>
            <th>ID</th>
            <td>34324234</td>
          </tr>
          <tr>
            <th>phone</th>
            <td>32132132</td>
            <th>country</th>
            <td>assuit</td>
          </tr>
          <tr>
            <th>city</th>
            <td>soso</td>
            <th>gender</th>
            <td>dfsdf</td>
          </tr>
          <tr>
            <th>password</th>
            <td>34244dsffd</td>
            <th>Email</th>
            <td>lkjdflksjf@ddsf,plpfg</td>
          </tr>
        </table>
      </div> -->
      <table  class="table table-bordered" class="form-control" style=" text-align: center; color: aliceblue;">

      <?php
      //matensash elqafla (</php/>)
        $result =  $Database->query("SELECT PAT_id, Name, phone, Email, Password, City, Street, Country, Gender, age FROM pateint");
  
        if($result->num_rows > 0)
        {
            echo "
            <tr id ='tr1'>
              <th>image</th>
              <th>ID</th>
              <th>name</th>
              <th>phone</th>
              <th>country</th>
              <th>city</th>
              <th>street</th>
              <th>gender</th>
              <th>password</th>
              <th>email</th>
              <th>Date Of Birth</th>
              <th>edit</th>
            </tr>";

            while ($row = $result->fetch_assoc())
            {
                echo '
                <tr id="tr2">
                    <td><img src="PFP.jpg" alt="" style="height: 70px; width: 70px; border-radius: 70px;"></td>
                    <td>' .$row["PAT_id"].' </td>
                    <td>' .$row["Name"].' </td>
                    <td>'.$row["phone"].' </td>
                    <td> '.$row["Country"].' </td>
                    <td>' .$row["City"].' </td>
                    <td> '.$row["Street"].' </td>
                    <td> '.$row["Gender"].' </td>
                    <td> '.$row["Password"].' </td>
                    <td> '.$row["Email"].' </td>
                    <td> '.$row["age"].' </td>
                    <td>         
                        <p class="title" class="dropdown-toggle" data-bs-toggle="dropdown">Edit</p>
                        <ul class="dropdown-menu">
                        <li style = " width: 100px; display:contents ; font-size: 16px; height: fit-content;"><a class="dropdown-item" name="del">Delete</a></li>
                        <li style = " width: 100px; display:contents ; font-size: 16px; height: fit-content;"><a class="dropdown-item" href="">Update</a></li>
                        </ul>
                    </td>

                </tr>
                
                ';
            }
        }

        //-------------------

        ?>
      </table>

      <!-- <div class="search1">
        <center>

            <img id="patient" src="istockphoto-1211161734-612x612-removebg-preview.png">
        </center>
        <form method="GET">
            <div class="row   justify-content-center" style="margin-top:auto;">

              <div class="col-md-8">

                <div class="search">
                  <i class="fa fa-search"></i>
                  <input type="text" class="form-control" placeholder="Find the patient" name="search">
                  <button class="btn btn-primary" name="btn-search" type="submit">Search</button>
                </div>
          </form> -->

  </div>

</body>



<style>
*{
    font-family: 'Times New Roman', Times, serif;
}

img
{
    height: 30px;
    width: 30px;
}

body {
    margin: 0px 0px 30px 0px;
}

body header{
    position:absolute;
    top: 0px;
    width: 100%;
    /* background: linear-gradient(#fff5e2, #ffffff); */
}

ul{
    margin: 0;
    padding: 0;
    /* navigatin bar background color */
    background-color: #0f0a0a;
    height: 50pX;
    /* navigatin bar bottom border color */
    border-bottom: #875749 solid 2.5px;
}
li{
    float: left;
    text-decoration: none;
    display: inline;
    margin-left: 30px;
    margin-right: 30px;
    padding: 0px 10px 0px 10px;
    /* navigatin bar text color */
    color: #fff5ef;
    font-size: 30px;
    font-weight: lighter;
}

.dropdown-menu {
    background-color: #fff5ef;
    height: fit-content;
    width: fit-content;
}

.dropdown-item{
    color: #0f0a0a;
}

.dropdown-item:hover
{
    color: #875749;
    background: none;
}

.li{
    width: 70px;
    display:contents ;
    font-size: 16px;
    height: fit-content;
}


li img {
    height: 30px;
    width: 30px;
}
.title{
    float: right;
    text-decoration: none;
}
.title:hover{
    /* navigatin bar text color on hover*/
    color: #c29c8e;
}

.div2
{
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    width: 100%;
    height: 500px;
    /* first div background color */
    background-color: #0f0a0a;
    /* navigatin bar bottom border color */
    border-bottom: #875749 solid 7px;
}

.div2 div 
{
    height: auto;
    width: 70%;
}

.div2 div input {
    outline: none;
    padding: 17px 17px 17px 17px;
    margin: 17px 0px 0px 0px;
    width: 100%;
    height: 55px;
    border: none;
    /* search bar border color */
    border: #875749 solid;
    border-radius: 9px;
}


.div2 h1 {
    /* first div text color */
    color: #ffffff;
    font-size: 77px;
}

#DIV{
    margin: 30px 30px 30px 30px;
    padding: 15px 15px 15px 15px;
    /* secound div background color */
    background-color: #c29c8e;
    border-radius: 7px;
}

tr,td,table 
{
    border: #0f0a0a solid 2.5px;
}

table
{
    border: #c29c8e solid 2.5px;
}



#tr1
{
    background-color: #875749;
    border: none;
}

#tr2
{
    background-color: #fff5ef;
    color: #0f0a0a;
}

table tr td {
  padding-right: 15px;
}

/* .but
{
    background: none;
    border: none;
} */
</style>
</html>