<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <div id = "majordiv">
        
        <h1>Add Appointment</h1>

        <form method ="POST">
            <!-- <input type="text" name = "id" placeholder="id" required/> --> 
            <div class = "input">
                <input type="text" name="Date" placeholder="Date : yyyy-mm-dd" class="c1" required/>
                <input type="text" name="Time" placeholder="Time : hh:mm" required/>
            </div>
            
            <div class = "input">
                <input type="text" name="Price" placeholder="Price" class="c1" required/>
                <input type="submit" name="send" value = "ADD">
            </div>
        </form>
    </div>

    <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Times New Roman', Times, serif;
        }
        body{
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background: #0f0a0a;
            /* background: linear-gradient(#fff5e2, #ffffff); */
        }

        #majordiv{
            border: #c29c8e solid;
            width: 50%;
            padding: 40px 30px 50px 30px;
            text-align: left;
            border-radius: 7px;
            background-color: #0f0a0a;
        }
        #majordiv h1{
            font-weight: lighter;
            font-size: 35px;
            color: #fff5e2;
        }

        form input {
            height: 50px;
            width: 45%;
            padding: 0px 30px ;
            font-size: 17px;
            border-radius: 7px;
            border: 1px solid #c29c8e;
            outline: none;
            color: #fff5e2;
            background-color: #0f0a0a;
            
        }

        form .input{
            margin-top: 30px;
        }

        .c1{
            margin-right: 8%;
        }

        form input::placeholder{
            font-weight: 30;
            font-size: 17px;
            color: #875749;
        }
        form input[type="submit"]{
            background-color: #875749;
            color: #fff5e2;
            cursor: pointer;
            transition: background 0.3s ease;
            font-size: 20px;
            font-weight: bold;
            border: 0px solid;
            margin-bottom: 0px;
        }
        form input[type="submit"]:hover{
            background: #fff5e2;
            color: #0f0a0a;
            border: 0px solid;
        }
    </style>
</body>
</html>

<?php
$Database = new mysqli("localhost","root", "", "clinic_managment_system_imra");

if (isset($_POST['send']))
{
    // $id = $_POST['id'];
    $Date = $_POST['Date'];
    $Time = $_POST['Time'];
    $Price = $_POST['Price'];
    $patsign = $Database->query("INSERT INTO appointment (/*PAT_id,*/ Date, Time, Price)
    VALUES ('$Date', '$Time', '$Price')");
}
?>