<?php
    $username='root';
    $password='';

    $DB = new mysqli("localhost", "$username", "$password", "clinic_system_managament");

    if(isset($_POST["send"]))
    {
        $Date = $_POST["D"];
        $Time = $_POST["T"];
        
        $DB->query("INSERT INTO appointment (Date, Time) VALUES ('$Date', '$Time')");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="POST">
        <input type="text" name = "D" placeholder="date | year-mounth-day">
        <input type="text" name = "T" placeholder="Time | Hour:minute">
        <button type="submit" name = "send"> submit </button>
    </form>
</body>
</html>