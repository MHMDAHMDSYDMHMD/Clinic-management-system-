
<?php
  $username="root";
  $password="";
  $database=new PDO("mysql:host=localhost; dbname=clinic_managment_system_imra;",$username ,$password);

?>