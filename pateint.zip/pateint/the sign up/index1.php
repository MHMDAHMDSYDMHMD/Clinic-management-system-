<?php

$username  = "root";
$password = "";
$database = new PDO("mysql:host=localhost;dbname=clinic_managament_system;charset=utf8;",$username,$password);
setcookie("login","wfe12@gmail.com",time()+60*60*24*30*12,"/localhost/all%20project/PROJECT%20pateint/","localhost",true,true);
if(isset($_POST['sginin']))
{

$checkemailandpass = $database->prepare("SELECT * FROM pateint WHERE Email = :email and Password = :password ");
$email = $_POST['email'];
$pass = $_POST['password'];

$checkemailandpass->bindParam("email",$email);
$checkemailandpass->bindParam("password",$pass);

$checkemailandpass->execute();


//
$checkpass = $database->prepare("SELECT * FROM pateint WHERE Password = :password ");
$pass = $_POST['password'];
$checkpass->bindParam("password",$pass);
$checkpass->execute();
//
$checkem = $database->prepare("SELECT * FROM pateint WHERE Email = :email ");
$ema = $_POST['email'];
$checkem->bindParam("email",$ema);
$checkem->execute();

if($checkemailandpass->rowCount()>0 )
{
  echo ' <script>
  alert("congratulation 🤩 The Account is existed");

  </script>'. '<br>';
    header("location:http://localhost/all%20project/PROJECT%20pateint/the%20home%20page/index.php");
  
}
else
{
if (!($checkem->rowCount()>0))
{
  echo ' <script>
  alert("email is not currect");

  </script>';}
elseif (!($checkpass->rowCount()>0))
{
  echo ' <script>
  alert("password is not currect");

  </script>';}
else
{
  echo ' <script>
  alert("Account not  existed");

  </script>';

}

}
} 
elseif(isset($_POST['sginup']) )
{
$check = $database->prepare("SELECT * FROM pateint WHERE Email = :email ");
$email = $_POST['email'];
$check->bindParam("email",$email);
$check->execute();
if($check->rowCount()>0)
{
  echo ' <script>
  alert("Tish Email is  Exist !");

  </script>';

}
else
{
$name = $_POST['name'];//1
$email = $_POST['email'];//2
$age = $_POST['barthday'];//3
$phone = $_POST['phone'];//4
$city = $_POST['city'];//5
$street = $_POST['street'];//6
$country = $_POST['country'];//7
$password = $_POST['password'];//8
$gender = $_POST['gender'];//9
$filename = $_FILES['file']["name"];
$filetype = $_FILES['file']["type"];
$filedata = file_get_contents($_FILES['file']["tmp_name"]);

//insert

$adduser = $database->prepare("INSERT INTO pateint ( Name ,phone ,Email ,Password ,City ,Street ,Country ,age ,Gender ,Image_of_pateint,Image_of_pateint_name,Image_of_pateint_type )VALUES (:name ,:phone ,:email ,:password ,:city ,:street ,: ,:age, :gender , :file,:filename,:filetype)");
$adduser->bindParam("name",$name);//2
$adduser->bindParam("email",$email);//3
$adduser->bindParam("password",$password);//4
$adduser->bindParam("city",$city);//5
$adduser->bindParam("street",$street);//6
$adduser->bindParam("country",$country);//7
$adduser->bindParam("phone",$phone);//8
$adduser->bindParam("age",$age);//9
$adduser->bindParam("gender",$gender);//10
$adduser->bindParam("file", $filedata);
$adduser->bindParam("filename", $filename);
$adduser->bindParam("filetype", $filetype);
setcookie("login",$email,time()+60*60*24*30*12,"/localhost/all%20project/PROJECT%20pateint/","localhost",true,true);
if($adduser->execute())
{
  echo ' <script>
  alert("Account Successfully created");

  </script>';
    header("location:http://localhost/all%20project/PROJECT%20pateint/the%20home%20page/index.php");

}
else
{
    echo "Re-register";
}
}
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>ContantUs | IMRA</title>
		<link rel="stylesheet" type="text/css" href="slide navbar style.css">
		<link rel="icon" href="../logoproject.png">
<style>
body{
	margin: 0;
	padding: 0;
	display: flex;
	justify-content: center;
	align-items: center;
	min-height: 100vh;
	font-family: 'Jost', sans-serif;
	background: linear-gradient(to bottom, #03035e, #0077b6);
}
.main{
	
	width: 350px;
	height: 990px;
	background: red;
	overflow: hidden;
	background: url("https://doc-08-2c-docs.googleusercontent.com/docs/securesc/68c90smiglihng9534mvqmq1946dmis5/fo0picsp1nhiucmc0l25s29respgpr4j/1631524275000/03522360960922298374/03522360960922298374/1Sx0jhdpEpnNIydS4rnN4kHSJtU1EyWka?e=view&authuser=0&nonce=gcrocepgbb17m&user=03522360960922298374&hash=tfhgbs86ka6divo3llbvp93mg4csvb38") no-repeat center/ cover;
	border-radius: 10px;
	box-shadow: 5px 20px 50px #000;
}
#chk{
	display: none;
}
.signup{
	position: relative;
	width:100%;
	height: 100%;
}
label{
	color: #fff;
	font-size: 2.3em;
	justify-content: center;
	display: flex;
	margin: 60px;
	font-weight: bold;
	cursor: pointer;
	transition: .5s ease-in-out;
}
input{
	width: 60%;
	height: 20px;
	background: #e0dede;
	justify-content: center;
	display: flex;
	margin: 20px auto;
	padding: 10px;
	border: none;
	outline: none;
	border-radius: 5px;
}
button{
	width: 60%;
	height: 40px;
	margin: 10px auto;
	justify-content: center;
	display: block;
	color: #fff;
	background: #03035e;
	font-size: 1em;
	font-weight: bold;
	margin-top: 20px;
	outline: none;
	border: none;
	border-radius: 5px;
	transition: .2s ease-in;
	cursor: pointer;
}
button:hover{
	background: #30305e;
}
.login{
	width: 350px;
	height: 900px;
	background: #eee;
	border-radius: 60% / 10%;
	transform: translateY(-180px);
	transition: .8s ease-in-out;
}
.login label{
	color: #03035e;
	transform: scale(.6);
}

#chk:checked ~ .login{
	transform: translateY(-990px);
}
#chk:checked ~ .login label{
	transform: scale(1);	
}
#chk:checked ~ .signup label{
	transform: scale(.6);
}
#exampleSelect{
	width: 230px;
	height: 30px;

}
#forpwd{
	font-size: small;
	align-items: center;
	text-align: center;
}
input[type="file"]{display: none;}
img{cursor: pointer;}

</style><link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">

</head>
<body>
	<div class="main">  	
		<input type="checkbox" id="chk" aria-hidden="false">

			<div class="signup">
				<form method="POST">
					<label for="chk" aria-hidden="true">Sign up</label>
<center>
	<img src="icons8-add-user-male-50.png" alt="" style="height :100px; width: 100px;">
</center> 
<br>
                    <input type="file" name="file" />
					<input name="name" type="text" name="txt" placeholder="Name" required="">
					<input name="email" type="email" name="email" placeholder="Email" required="">
					<input name="phone" type="number" name="pswd" placeholder="Phone" required="">
					<input name="barthday" type="text" name="pswd" placeholder="Barthday" required="">
					<input name="street" type="text" name="pswd" placeholder="Street" required="">
					<input name="city" type="text" name="pswd" placeholder="City" required="">
					<input name="country" type="text" name="pswd" placeholder="Country" required="">
			<center><div class="form-floating">
                    <select  name="gender" class="form-select" id="exampleSelect" required>
        			<option >Man</option>
                    <option >Women</option>  
				    </select>
			        </div></center>		
					<input name="password" type="password"  placeholder="Password" required="">
					<button name="signup">Sign up</button>
				</form>
			</div>
<br>
			<div class="login" >
				<form method="POST">
					<label for="chk" aria-hidden="true">Login</label>
					<input type="email" name="email" placeholder="Email" required="">
					<input type="password" name="password"placeholder="Password" required="">
					<button name="sginin">Login</button>
				<center><a href="../the forget password/index.php" id="forpwd">Forget Password</a></center>
				</form>
			</div>
	</div>
	<script>
  document.getElementById("lood").hidden=true;
  function uploadphoto(){
    document.getElementById("lood").hidden=false;

  }
  function le(){
	document.getElementById("lood").hidden=true;
  }
  </script>
  <script>
	let imgbtn = document.querySelector('img');
	let fileinp = document.querySelector('[type="file"]');
	imgbtn.addEventListener('click',function () 
	{
		fileinp.click();
	})
  </script>
</body>
</html>