<?php
$username  = "root";
$password = "";
$database = new PDO("mysql:host=localhost;dbname=clinic_managament_system;charset=utf8;",$username,$password);  
// if(isset($_COOKIE['login']))
// {

// $cook= $_COOKIE['login'];
$gett = $database->prepare("SELECT * from pateint WHERE PAT_id = 13");
// $gett->bindParam("email",$cook);
$gett->execute();
foreach($gett as $g){}
$id =  $g['PAT_id'];
$name =  $g['Name'];
$email =  $g['Email'];
$phone =  $g['phone'];
$street	 =  $g['Street'];
$country	 =  $g['Country'];
$city =  $g['City'];
$image_of_pateint =  $g['Image_of_pateint'];
$gender =  $g['Gender'];
$age =  $g['age'];
// }

##################################################
  if(isset($_POST['sure']) )
    {
      $checkpass = $database->prepare("SELECT Password FROM pateint WHERE PAT_id = :id ");
      $checkpass->bindParam("id",$id);
      $checkpass->execute();
      foreach($checkpass as $ch){}
      $pass = $_POST['password'];
  if($pass == $ch[0]) {
    
    $name = $_POST['name'];//1
    $age = $_POST['barthday'];//3
    $phone = $_POST['phone'];//4
    $city = $_POST['city'];//5
    $street = $_POST['street'];//6
    $country = $_POST['country'];//7
    $gender = $_POST['gender'];//9
    $filename = $_FILES['file']["name"];
    $filetype = $_FILES['file']["type"];
    $filedata = file_get_contents($_FILES['file']["tmp_name"]);
    //update
    
    $adduser = $database->prepare("UPDATE pateint SET Name = :name ,phone= :phone,City = :city ,Street=:street ,Country=:country  ,age=:age ,Gender=:gender  ,Image_of_pateint=:file,Image_of_pateint_name=:filename,Image_of_pateint_type=:filetype  WHERE PAT_id = :id");
    $adduser->bindParam("name",$name);//2
    $adduser->bindParam("city",$city);//5
    $adduser->bindParam("street",$street);//6
    $adduser->bindParam("country",$country);//7
    $adduser->bindParam("phone",$phone);//8
    $adduser->bindParam("age",$age);//9
    $adduser->bindParam("gender",$gender);//10
    $adduser->bindParam("file", $filedata);
    $adduser->bindParam("filename", $filename);
    $adduser->bindParam("filetype", $filetype);
    $adduser->bindParam("id", $id);
   
    if($adduser->execute())
    {
        echo '<br> <p class="alert alert-primary">Account Successfully updated</p>';
    
    }
    else
    {
        echo "Re-register";
    }
    }
    else
    {
      echo '<br> <p class="alert alert-primary">password is not currect</p>';

    }
      
  }
  


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.104.2">
    <title>Edit | IMRA</title>
    <style>
      body{
        font-family: 'Times New Roman', Times, serif !important;
background-color: rgb(110, 161, 255)!important;
      }
      #act{
          color:aquamarine !important;
        }
    </style>
    
    <link rel="stylesheet" href="./Cairo/static/Cairo-Black.ttf">
    <link rel="icon" href="../logoproject.png">
    
    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/sign-in/">


    <link href="./Cairo/static/Cairo-Black.ttf" rel="stylesheet">

    <link href="bootstrap.min.css" rel="stylesheet">

    <style>
     
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        
        }
      }

      .b-example-divider {
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    
<main class="form-signin w-100 m-auto">
  <form method= "POST">
    <h1 class="h3 mb-3 fw-normal">Please retype your information </h1>
<center><img src="testimonial-1.png" alt="" onclick="uploadphoto()" value="<?php
base64_decode($image_of_pateint);
?>" onmouseleave="le()" style="border-radius: 50%;height :255px; width: 255px;"></center> <br>
<input name="file" type="file" id="looooood">
    <div class="form-floating">
      <input  name="name" type="text" class="form-control" id="floatingInput" value="<?php echo $name ?>" placeholder="name@example.com">
      <label for="floatingInput">Name</label>
    </div>

    
    <div class="form-floating">
      <input name="phone" type="text" class="form-control" id="floatingPassword" value="<?php echo  $phone ?>"placeholder="Password">
      <label for="floatingPassword">Phone</label>
    </div> 

    <div class="form-floating">
      <input  name="barthday" type="text" class="form-control" id="floatingPassword"value="<?php  echo $age ?>" placeholder="Password">
      <label for="floatingPassword">Barthday</label>
    </div> 

      <div class="form-floating">
      <input name="city" type="text" class="form-control" id="floatingInput" value="<?php  echo $city ?>" placeholder="name@example.com">
      <label for="floatingInput">City</label>
    </div>
    
    <div class="form-floating">
      <input name="street"type="text" class="form-control" id="floatingPassword" value="<?php  echo $street ?>"placeholder="Password">
      <label for="floatingPassword">Street</label>
    </div>
    
    
    <div class="form-floating">
      <input name="country" type="text" class="form-control" id="floatingInput"value="<?php  echo $country ?>" placeholder="name@example.com">
      <label for="floatingInput">Country</label>
    </div>
    
    <div class="form-floating">
      <select  name="gender" value="<?php  echo $gender ?>" class="form-select" id="exampleSelect">
        <option >Man</option>
        <option >Women</option>  
      </select>
      <label for="floatingPassword"> Gender</label>
    </div>
    

   <label for="text"> "you must write the password to finish edit proccess"</label>
    <div class="form-floating">
    <input name="password" type="password" class="form-control" id="floatingPassword" placeholder="Password" required> 
    <label for="floatingPassword">Password</label>
  </div>
  <button name="sure" class="w-100 btn btn-lg btn-primary" type="submit" style="background-color: rgb(4, 0, 66); border-color: blue;">sure</button>
     </form>
</main>

<script>
  document.getElementById("looooood").hidden=true;
  function uploadphoto(){
    document.getElementById("looooood").hidden=false;

  }
</script>
    
  </body>
</html>
