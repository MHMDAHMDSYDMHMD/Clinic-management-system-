<?php
 setcookie("login","wfe12@gmail.com",time()+60*60*24*30*12,"/localhost/all%20project/PROJECT%20pateint/","localhost",true,true);

$username  = "root";
$password = "";
$database = new PDO("mysql:host=localhost;dbname=clinic_managament_system;charset=utf8;",$username,$password);  
if(isset($_COOKIE['login']))
{

$cook= $_COOKIE['login'];
$gett = $database->prepare("SELECT * from pateint WHERE Email = :email");
$gett->bindParam("email",$cook);
$gett->execute();
foreach($gett as $g){}
$id =  $g['PAT_id'];
$name =  $g['Name'];
$email =  $g['Email'];
$phone =  $g['phone'];
$street	 =  $g['Street'];
$country	 =  $g['Country'];
$city =  $g['City'];
$image_of_pateint =  $g['Image_of_pateint'];
$gender =  $g['Gender'];
$age =  $g['age'];
$AGE = "";
for($i =  0; $i<= 10;$i++ )
{
  $AGE .= $age[$i];
if ($i==3) {
 break;
}
}
$calcage = (int)date("Y") - (int)$AGE ;
#   /\               /\
   //\\             //\\
  //||\\appointment//||\\
$selectdataappointment = $database->prepare("SELECT *  FROM appointment  where   PAT_id = :id");
$selectdataappointment->bindParam("id",$id);
$selectdataappointment->execute();

//  /\               /\
   //\\             //\\
  //||\\prescription//||\\
  
    $selectdataprescription = $database->prepare("SELECT *  FROM prescription where PAT_id = :iid");
    $selectdataprescription->bindParam("iid",$id);
    $selectdataprescription->execute();
 

  
 if (isset($_POST['deleteing'])){
  $delete = $database->prepare("DELETE FROM pateint WHERE APP_id = :id");
  $delete->bindParam("id",$id);
 if($delete->execute()){
  echo ' <script>
  alert("Account successfully deleted");
  this.close();
  </script>';
  header("location:http://localhost/all%20project/PROJECT%20pateint/the%20home%20page%20VISITOR/");
 }
 }
}

?>
<!-- HTML -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>IMRA | Account</title>
    <style>
        body{
          font-family: 'Times New Roman', Times, serif !important;
        }
        #act{
          color:aquamarine !important;
        }
        .mu-footer-top{
        height: 280px !important;
      }
      </style>
      
      <link rel="stylesheet" href="./Cairo/static/Cairo-Black.ttf">
      <link rel="icon" href="../logoproject.png">


    <!-- Favicon -->
    <link rel="shortcut icon" href="../assets/img/favicon.ico" type="image/x-icon">

    <!-- Font awesome -->
    <link href="../assets/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="../assets/css/slick.css">          
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="../assets/css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="../assets/css/theme-color/project-theme.css" rel="stylesheet">  

    <!-- Main style sheet -->
    <link href="../assets/css/style.css" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,300,300italic,500,700' rel='stylesheet' type='text/css'>
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body>
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->

  <!-- Start header  -->
  <header id="mu-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-header-area">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-left">
                  <div class="mu-top-email">
                    <i class="fa fa-envelope"></i>
                    <span>info@imra.io</span>
                  </div>
                  <div class="mu-top-phone">
                    <i class="fa fa-phone"></i>
                    <span>(568) 986 652</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-right">
                  <nav>
                    <ul class="mu-top-social-nav">
                      <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                      <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                      <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                      <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                      <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header  -->
  <!-- Start menu -->
  <section id="mu-menu">
    <nav class="navbar navbar-default" role="navigation" id="mu-menu-nav">  
      <div class="container">
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->              
          <!-- TEXT BASED LOGO -->

          <div>
            <a class="navbar-brand" href="index.php"><img src="../logoproject.png" alt="LOGO" style="width: 50px;height:50px;margin-top:-11px"></a>    
            <a class="navbar-brand" href="index.php"><span>IMRA</span></a> 
             </div> 
                       <!-- <a class="navbar-brand" href="index.php"><i class=""></i><span  class="imra">IMRA</span></a> -->
          <!-- IMG BASED LOGO  -->
          <!-- <a class="navbar-brand" href="index.php"><img src="../assets/img/logo.png" alt="logo"></a> -->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
            <li class="active"><a href="../the home page/index.php">Home</a></li>            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">login <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="..\the sign up\index.php">Sing up</a></li>                
                <li><a href="..\the login page\index.php">login</a></li>                
              </ul>
            </li>           
       
            <li><a href="..\the about us page\about_us.php">About us</a></li>
            <li><a href="..\the Account page\Account.php">Account</a></li>
            <li><a href=" ..\the reserved page\the reserved page.php ">reserve</a></li>          
            <li><a href="index.php">Chat</a></li>  
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">mode <span class="fa fa-angle-down"></span></a>
              <ul  class="dropdown-menu" role="menu">
             
                       <li><button class="btn btn-primary" onclick="dark_mode()"  style="width: 190px; background-color: rgb(0, 142, 204);color:antiquewhite; border-color: #a8938c;" name="dark">dark</button></li>               
                       <li><button class="btn btn-primary" onclick="light_mode()" style="width: 190px; background-color: rgb(0, 142, 204);color:antiquewhite;border-color: #a8938c;"name="dark">light</button></li>                
                       
                      </ul>
            </li>        



            <li><a href="#" id="mu-search-icon"><i class="fa fa-search"></i></a></li>
          </ul>                     
        </div><!--/.nav-collapse -->        
      </div>     
    </nav>
  </section>
  <!-- End menu -->
  <!-- Start search box -->
  <div id="mu-search">
    <div class="mu-search-area">      
      <button class="mu-search-close"><span class="fa fa-close"></span></button>
      <div class="container">
        <div class="row">
          <div class="col-md-12">            
            <form class="mu-search-form">
              <input type="search" placeholder="Type Your Keyword(s) & Hit Enter">
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- End search box -->
 <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-page-breadcrumb-area">
           <h2>Account</h2>
           <ol class="breadcrumb">
            <li><a href="..\the home page\index.php">Home</a></li>            
            <li class="active" id="act">Account</li>
          </ol>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- End breadcrumb -->
 <section id="mu-course-content" id="d1">
   <div class="container" id="d2">
     <div class="row" id="d3">
       <div class="col-md-12" id="d4">
         <div class="mu-course-content-area" id="d5">
            <div class="row" id="d5">
              <div class="col-md-9" id="d6">
                <!-- start course content container -->
                <div class="mu-course-container mu-course-details" id="d7">
                  <div  class="row" id="d8">
                    <div class="col-md-12" id="d9">
                      <div class="mu-latest-course-single" id="d10">
                        <figure style="width: 350px ;"  class="mu-latest-course-img" id="d11">
                          <a href="#"><img style="width: 250px; height: 250px;" value="<?php
base64_decode($image_of_pateint);
?>"  src="../assets/img/courses/1.jpg" alt="img"></a>
                        </figure>
                        <div class="mu-latest-course-single-content" id="mu-latest-course-single-content" id="d12">
                          <h2><a href="#">Information About Me</a></h2>
                          <h4 id="me" style="color: #0f0a0a; font-style: italic;">personality Information</h4>
                          <ul id="ul">
                            <li> <span>Name :</span> <span><?php echo $name;?></span></li>
                            <li> <span>Phone :</span> <span><?php echo $phone;?></span></li>
                            <li> <span>Email :</span> <span><?php echo $email;?></span></li>
                            <li> <span>Address </span> <span>is :</span>
                              <div class="mu-latest-course-single-content" id="mu-latest-course-single-content"id="d13">
                                <NAV id="d14">
                              <ul id="d15">
                              <li><span>Street :</span><span><?php echo $street;?></span> </li> 
                              <li><span>City :</span><span><?php echo $city;?></span> </li> 
                              <li><span>Country :</span><span><?php echo $country;?></span> </li> 
                            </ul>
                          </NAV>
                        </div>
                          </li> 
                          <li> <span>Gender :</span> <span></span><?php echo $gender;?></li>
                            <li> <span>Age :</span> <span><?php echo $calcage;?></span></li>
                          </ul>
                          
                          <div id="table-history" id="d16">
                            
                         <h4  style="color: #0f0a0a;font-style: italic;">Reserved</h4>
                          <div  class="table-responsive" id="d17"> 
                            <form action="" id="d18">
                            <label for="search">
                              search by Reserved number:
                            </label>
                            <input type="search" placeholder="Type reserved number" >
                            <label for="search">
                              search by Reserved date:
                            </label>
                            <input type="search" placeholder="Type reserved date">
                            <br><br>
                            <label for="search">
                              search by Reserved Type:
                            </label>
                            <input type="search" placeholder="Type Reserved Type">
                            <label for="search">
                              search by any thing or Type Hit :
                          </label>
                          <input type="search" placeholder="Type Your Keyword(s) & Hit Enter">
                          </form>
                            <table class="table" id="d19">
                            <h3>Reserved</h3>
                            <thead>
                              <tr>
                                <th>The reserved </th>
                                <th>  Time </th>
                                <th> Date  </th>
                                <th> Reserved Type </th>
                                <th> Status </th>
                              </tr>
                            </thead>
                            <tbody>

                        <?php   
                         foreach($selectdataappointment as $dataa){ 
                              echo '
                              <tr id="reserved 1" style="color: rgb(77, 77, 77);">
                                <td> '.$dataa['APP_id'].'</td>
                                <td> '.$dataa['Time'].' </td>
                                <td>  '.$dataa['Date'].' </td>
                                <td>  '.$dataa['type'].'</td>
                                <td>  '.$dataa['status'].' </td>
                                </tr>
                              '; }
                              ?>
                           </tbody>
                           <TH>    <h3>Prescription</h3></TH>

                           <thead>

                              <tr>
                              <th>Prescription </th>
                                <th>  medicine </th>
                                <th> medicine-times  </th>
                                <th> report </th>
                                <th> rurour </th>
                                <th> notes </th>
                              </tr>
                            </thead>

                            <tbody>

<?php   
  foreach($selectdataprescription as $datap ){
      echo '
      <tr id="reserved 1" style="color: rgb(77, 77, 77);">
        <td>  '.$datap['PRE_id'].' </td>
        <td> '.$datap['Medicine'].'</td>
        <td>  '.$datap['Medicine_Times'].'</td>
        <td>  <a href="http://localhost/phpmyadmin/index.php?route=/table/get-field&db=clinic_managament_system&table=prescription&where_clause_sign=27d8d1084c769fb12a981220b5977b955dd8dcfc69b7545f56ed78b5ce5c6d3e&where_clause=%60prescription%60.%60PRE_id%60+%3D+3&transform_key=report&sql_query=SELECT+%2A+FROM+%60prescription%60">
        ✔ "DOWNLOAD"<img src="data.image/png;base64,'.base64_encode($datap['report']).'"> </td>
        <td><a href="http://localhost/phpmyadmin/index.php?route=/table/get-field&db=clinic_managament_system&table=prescription&where_clause_sign=b565e5dad5f342f60c007dc4b48003d983013ff1be3d21eef9d4976d730b0f90&where_clause=%60prescription%60.%60PRE_id%60+%3D+1&transform_key=rurour&sql_query=SELECT+%2A+FROM+%60prescription%60">
        ✔ "DOWNLOAD"
        <img src="data.image/png;base64,'.base64_encode($datap['rurour']).' "> 
        </a> </td>
        <td > busdam officia suscipit qui illum nemo itaque, porro ipsam tempore  </td>
      </tr>
      '; }
      ?>
   </tbody>                        

                          </table>
                          <button onclick="shoow()" class="btn btn-primary" style="background: linear-gradient(#0145ff,#041ba0,#0c0038); border-color: black;"> Hidden</button>
                      <br>
                        </div>
                          </div>
                        </div>
                      </div> 
                    </div>                                   
                  </div>
                </div>
                <!-- end course content container -->
                <!-- start related course item -->
                

              </div>

              <div class="col-md-3" >
                <!-- start sidebar -->
                <aside class="mu-sidebar" >
                  <!-- start single sidebar -->
                  <div class="mu-single-sidebar" id="mu-menu-aside">
                    <h3>My Content</h3>
                    <ul class="mu-menu-ul" class="mu-sidebar-catg">
                      <li class="mu-menu-ul"><a href="#me">ME</a></li>
                      <li class="mu-menu-ul"><a onclick=" hid()" href="#table-history">MY History</a></li>
                      <li class="mu-menu-ul"><a onclick=" OPENPAGE()" href="">Edit</a></li>
                      <li class="mu-menu-ul">
                        <form action="" method="POST">
                        <button name="deleteing" class="btn btn-warning" style ="background-color : red ;"> Delete My Account </button>
                        </form></li>


                      
                    </ul>
                  </div>
                  <!-- end single sidebar -->
                  <!-- start single sidebar -->
                  <!-- end single sidebar -->
                  <!-- start single sidebar -->
                  <!-- end single sidebar -->
                  <!-- start single sidebar -->
                  <!-- end single sidebar -->
                </aside>
                <!-- / end sidebar -->
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>

  <!-- Start footer -->
  <footer id="mu-footer">
    <!-- start footer top -->
    <div class="mu-footer-top">
      <div class="container">
        <div class="mu-footer-top-area">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Information</h4>
                <ul>
                  <li><a href="#">About Us</a></li>
                  <li><a href="">resaerve</a></li>
                 
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4> Help</h4>
                <ul>
                  <li><a href="">Chat</a></li>
                                 
                </ul>
              </div>
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Contact</h4>
                <address>
                  <p>P.O. Box 320, Ross, ASSUIT 9495, EGY</p>
                  <p>Phone: (415) 453-1568 </p>
                  <p>Website: www.imra.io</p>
                  <p>Email: info@imra.io</p>
                </address>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end footer top -->
  
    <!-- end footer bottom -->
  </footer>
  <!-- End footer -->



<script>
    const table_history_var= document.getElementById("table-history");
    table_history_var.hidden=true;

function hid(){
    table_history_var.hidden=false;
}
function shoow(){
    table_history_var.hidden=true;
}
function OPENPAGE(){
  window.open("..\\the edit\\index.php","width:600px;height:600px;top:250px;right:250px;bottom:250px;left:250px;")
}
</script>

  
  <!-- jQuery library -->
  <script src="../assets/js/jquery.min.js"></script>  
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../assets/js/bootstrap.js"></script>   
  <!-- Slick slider -->
  <script type="text/javascript" src="../assets/js/slick.js"></script>
  <!-- Counter -->
  <script type="text/javascript" src="../assets/js/waypoints.js"></script>
  <script type="text/javascript" src="../assets/js/jquery.counterup.js"></script>  
  <!-- Mixit slider -->
  <script type="text/javascript" src="../assets/js/jquery.mixitup.js"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="../assets/js/jquery.fancybox.pack.js"></script>

  <!-- Custom js -->
  <script src="../assets/js/custom.js"></script> 

  <script>
  function dark_mode(){
document.body.style.background = "black";
document.body.style.color="white";

document.getElementById("mu-header").style.background = "black";
document.getElementById("mu-header").style.color="rgb(0, 142, 204)";


document.getElementById("mu-menu").style.background = "black";
document.getElementById("mu-menu").style.color="rgb(0, 142, 204)";

document.getElementById("mu-menu-nav").style.background = "black";
document.getElementById("mu-menu-nav").style.color="rgb(0, 142, 204)";

document.getElementById("mu-course-content").style.background = "black";
document.getElementById("mu-course-content").style.color="rgb(0, 142, 204)";

document.getElementById("mu-menu-aside").style.background = "black";
document.getElementById("mu-menu-aside").style.color="rgb(0, 142, 204)";

document.getElementById("mu-menu-ul").style.color="rgb(0, 142, 204)";
document.getElementsByClassName("mu-menu-ul").style.color="rgb(0, 142, 204)";


document.getElementsByClassName("mu-latest-course-single").style.background = "black";
document.getElementsByClassName("mu-latest-course-single").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("col-md-12").style.background = "black";
document.getElementsByClassName("col-md-12").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("mu-course-details").style.background = "black";
document.getElementsByClassName("mu-course-details").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("mu-course-container").style.background = "black";
document.getElementsByClassName("mu-course-container").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("mu-latest-course-img").style.background = "black";
document.getElementsByClassName("mu-latest-course-img").style.color="rgb(0, 142, 204)";


document.getElementById("mu-latest-course-single-content").style.background = "black";
document.getElementById("mu-latest-course-single-content").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("mu-latest-course-single-content").style.background = "black";
document.getElementsByClassName("mu-latest-course-single-content").style.color="rgb(0, 142, 204)";


document.getElementById("table-history").style.background = "black";
document.getElementById("table-history").style.color="rgb(0, 142, 204)";

document.getElementById("ul").style.background = "black";
document.getElementById("ul").style.color="rgb(0, 142, 204)";

document.getElementsByClassName("table-responsive").style.background = "black";
document.getElementsByClassName("table-responsive").style.color="rgb(0, 142, 204)";
 
document.getElementsByTagName("table").style.background = "black";
document.getElementsByTagName("table").style.color="rgb(0, 142, 204)";
//d

document.getElementById("d1").style.background = "black";
document.getElementById("d1").style.color="rgb(0, 142, 204)";

document.getElementById("d2").style.background = "black";
document.getElementById("d2").style.color="rgb(0, 142, 204)";

document.getElementById("d3").style.background = "black";
document.getElementById("d3").style.color="rgb(0, 142, 204)";

document.getElementById("d4").style.background = "black";
document.getElementById("d4").style.color="rgb(0, 142, 204)";

document.getElementById("d5").style.background = "black";
document.getElementById("d5").style.color="rgb(0, 142, 204)";

document.getElementById("d6").style.background = "black";
document.getElementById("d6").style.color="rgb(0, 142, 204)";

document.getElementById("d7").style.background = "black";
document.getElementById("d7").style.color="rgb(0, 142, 204)";

document.getElementById("d8").style.background = "black";
document.getElementById("d8").style.color="rgb(0, 142, 204)";

document.getElementById("d9").style.background = "black";
document.getElementById("d9").style.color="rgb(0, 142, 204)";

document.getElementById("d10").style.background = "black";
document.getElementById("d10").style.color="rgb(0, 142, 204)";

document.getElementById("d11").style.background = "black";
document.getElementById("d11").style.color="rgb(0, 142, 204)";

document.getElementById("d12").style.background = "black";
document.getElementById("d12").style.color="rgb(0, 142, 204)";

document.getElementById("d13").style.background = "black";
document.getElementById("d13").style.color="rgb(0, 142, 204)";

document.getElementById("d14").style.background = "black";
document.getElementById("d14").style.color="rgb(0, 142, 204)";

document.getElementById("d15").style.background = "black";
document.getElementById("d15").style.color="rgb(0, 142, 204)";

document.getElementById("d16").style.background = "black";
document.getElementById("d16").style.color="rgb(0, 142, 204)";

document.getElementById("d17").style.background = "black";
document.getElementById("d17").style.color="rgb(0, 142, 204)";

document.getElementById("d18").style.background = "black";
document.getElementById("d18").style.color="rgb(0, 142, 204)";

document.getElementById("d19").style.background = "black";
document.getElementById("d19").style.color="rgb(0, 142, 204)";






}
  function light_mode (){
document.body.style.background = "white";
document.body.style.color="black";

document.getElementById("mu-header").style.background = "white";
document.getElementById("mu-header").style.color="black";


document.getElementById("mu-menu").style.background = "white";
document.getElementById("mu-menu").style.color="rgb(0, 142, 204)";

document.getElementById("mu-menu-nav").style.background = "white";
document.getElementById("mu-menu-nav").style.color="rgb(0, 142, 204)";



  }
</script>
  </body>
</html>