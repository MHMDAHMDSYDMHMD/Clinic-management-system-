<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" href="../logoproject.png">
</head>
<body style="font-family: 'Times New Roman', Times, serif !important;">
    
</body>
</html>
<?php
 setcookie("login","wfe12@gmail.com",time()+60*60*24*30*12,"/localhost/all%20project/PROJECT%20pateint/","localhost",true,true);

if(isset($_COOKIE['login']))
{
echo '
<script> 
let x = confirm("you have Account already  !\\n do you want sgin up or sgin in (choose \"ok\") or no (choose \"cancel\") ") ; 
if(x)
{
    let i = confirm("sgin up  (choose \"ok\") or sgin in (choose \"cancel\") ") ; 
    if(i)
    {
        window.location="http://localhost/all%20project/PROJECT%20pateint/the%20sign%20up/";
    }
    else if (!i)
    {
        window.location="http://localhost/all%20project/PROJECT%20pateint/the%20login%20page/";
    }
}
else if(!x)
{
 window.location="http://localhost/all%20project/PROJECT%20pateint/the%20home%20page/index.php";
}
</script>';
}
?>