<?php
$username  = "root";
$password = "";
$database = new PDO("mysql:host=localhost;dbname=clinic_managament_system;charset=utf8;",$username,$password);  
if(isset($_COOKIE['login']))
{
$cook= $_COOKIE['login'];
$gett = $database->prepare("SELECT * from pateint WHERE Email = :email");
$gett->bindParam("email",$cook);
$gett->execute();
foreach($gett as $g){}
$id =  $g['PAT_id'];
//============ UPDATE ==============
if(isset($_POST['update'])){
  $appointment_id = $_POST['id'];
  $checkid=$database->prepare("SELECT * FROM appointment where APP_id = :id");
  $checkid->bindParam("id",$appointment_id);
  $checkid->execute();
  if($checkid->rowCount()>0){
    $date= $_POST['date'];
    $time= $_POST['time'];
  $checkupdate=$database->prepare("SELECT * FROM appointment where  Date = :date and Time = :time ");
$checkupdate->bindParam("date",$date);
$checkupdate->bindParam("time",$time);
$checkupdate->execute();
if($checkupdate->rowCount()>0){
  echo '
  <script> 
let x = alert("this appointment is reserved previously") ; 
</script> 
  ';
}
else 
{
  $update = $database->prepare("UPDATE appointment SET DATE = :date ,Time = :time  WHERE APP_id = :id");
  $update->bindParam("id",$appointment_id);
  $update->bindParam("date",$date);
$update->bindParam("time",$time);
 if($update->execute()){
  header("location:http://localhost/all%20project/PROJECT%20pateint/the%20reserved%20page%20-%20my%20reserveds/the%20reserved%20page.php");
 }

}
}
 }
}
if(isset($_POST['close'])){
  header("location:http://localhost/all%20project/PROJECT%20pateint/the%20reserved%20page%20-%20my%20reserveds/the%20reserved%20page.php");

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Reserved | IMRA</title>
  <style>
      body{
        font-family: 'Times New Roman', Times, serif !important;
      }
      #act{
          color:aquamarine !important;
        }
    </style>
    
    <link rel="stylesheet" href="../Cairo/static/Cairo-Black.ttf">
    <link rel="icon" href="logoproject.png">
    <!-- Favicon -->

    <!-- Font awesome -->
    <link href="../assets/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="../assets/css/bootstrap.css" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="../assets/css/slick.css">          
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="../assets/css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="../assets/css/theme-color/project-theme.css" rel="stylesheet">  

    <!-- Main style sheet -->
    <link href="../assets/css/style.css" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:10,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:10,10italic,300,300italic,500,700' rel='stylesheet' type='text/css'>
    
</head>
<body>
<center>
 <main style="margin-top:300px" class="form-signin w-100 m-10">
  <form action="" method="POST">
 <!-- End breadcrumb -->
 <div class="form-floating">
  <label style="margin-right:470px;" for="floatingPassword" style="width: 10px;">ID-RESERVED</label>

  <input  name="id" style="width: 500px;" type="id" class="form-control" id="floatingPassword"  required>
</div>

 <div class="form-floating">
  <label style="margin-right:470px;" for="floatingPassword" style="width: 10px;">Date</label>

  <input  name="date" style="width: 500px;" type="date" class="form-control" id="floatingPassword"  required>
</div>
<div class="form-floating">
    <label style="margin-right:470px;" for="floatingPassword">Time</label>

  <input  name="time"style="width: 500px;" type="time" class="form-control" id="floatingPassword" placeholder="Password"required>
</div>           <br>
<button  name="update" class="btn btn-primary" > Update </button>
</form> </main><br>
<form action="" method="POST">
<button name="close"  class="btn btn-primary" style="background-color:red;border-color:black;color:white;">close</button>
      </form>
            </center>
</body>
</html>



