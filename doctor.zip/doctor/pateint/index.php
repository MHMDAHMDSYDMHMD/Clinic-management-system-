

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="patientStyle.css">
    <link href="linkBootstrap.css"rel="stylesheet">
    

</head>
<body style="background: linear-gradient(to right,#03035e,#0077b6">
    <nav  style="background: linear-gradient(to right,#03035e,#0077b6">
        <ul class="nav justify-content-center menu3" >
      
      
            <li class="nav-item ">
              <a class="nav-link " href="..\doctorHome\DocHome.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; " >Doctor Home</a>  
            </li>
      
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\Appointment\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; ">Appointment</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\prescription\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; ">Prescription</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\pateint\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Patient</a> 
            </li>
            <div class="action">
              <div class="profile" >
                <img src="icon-6007530__340.png" onclick="menuToggle();" >
                </div>
                <?php
                include('..\connect_to_database.php');
                 $data=$database->prepare("SELECT * FROM `doctor` ");
                 $data->execute();
                 foreach($data AS $select){
                 } 

                 echo'
         <div class="menu">
           <h3>
             Dr/'
             .$select['Name'].
             '<br>
             <span>
               Doctor in '
               .$select['Specialization'].
           '</span>
                  </h3>
                  <ul>
                    <li>
                      <img src="client+person+photo+picture+profile+user+icon-1320184631024101186.png" >
                      <a href="..\Account\index.php">My Profile</a>
                    </li>
                    <li>
                      <img src="736670-200.png">
                      <a href="..\signup\index.php">Signup</a>
                    </li>
                    <li>
                      <img src="free-user-logout-icon-3056-thumb.png">
                      <a href="..\mainHome\index.html">Logout</a>
                    </li>
          
                      
                  </ul>
                </div>
              </div>'
              ?>
              <script>
                  function menuToggle(){
                    const ToggleMenu=document.querySelector('.menu');
                    ToggleMenu.classList.toggle('active');
                  }
                </script>
      
        </ul>
      
      </nav> 
      

      <div class="search1">
        <center>

            <img id="patient" src="istockphoto-1211161734-612x612-removebg-preview.png">
        </center>
        <form method="GET">
            <div class="row   justify-content-center" style="margin-top:auto;">

              <div class="col-md-8">

                <div class="search">
                  <i class="fa fa-search"></i>
                  <input type="text" class="form-control" placeholder="Find the patient" name="search">
                  <button class="btn btn-primary" name="btn-search" type="submit">Search</button>
                </div>
          </form>




            <?php
 if(isset($_GET['btn-search'])){
  $search=$database->prepare("SELECT * FROM pateint WHERE Name LIKE :value");
  $search_Value="%".$_GET['search']."%";
  $search->bindParam("value",$search_Value);
  $search->execute();
  foreach($search AS $data){
  $id="%".$data['PAT_id']."%";

  $Prescription_data=$database->prepare("SELECT * FROM prescription WHERE PAT_id LIKE :value");
 $Prescription_data->bindParam("value",$data['PAT_id']);
  $Prescription_data->execute();

}
    if($search->rowCount()===0){
      echo '<div class="alert alert-primary d-flex align-items-center" role="alert" style="margin-top:15px;">
      
      <div >
        <strong>No Pateint!</strong>You Should Check The Pateint Name.

        </div>
        
    </div>';

    }else{
      echo'          <table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align: center;">
      <tr style="background-color:white;color:#021f73;">
        <th>
          ID
        </th>
        <th>
          Name
        </th>
        <th>
          Phone
        </th>
        <th>
          Gender
        </th>
        <th>
          Email
        </th>
        <th>
          Appointment
        </th>

        <th>
        Diagnosis
        </th>
      </tr>  ';
      $search=$database->prepare("SELECT * FROM pateint WHERE Name LIKE :value");
      $search_Value="%".$_GET['search']."%";
      $search->bindParam("value",$search_Value);
      $search->execute();
      foreach($search AS $data){ 
        $app=$database->prepare("SELECT * FROM appointment WHERE PAT_id LIKE :value");
        $app_Value=$data['PAT_id'];
        $app->bindParam("value",$app_Value);
        $app->execute();
        foreach($app AS $data_app){        
        echo'
                <tr >
                  <th>
                      '

                          .$data['PAT_id'].
                      '
                  </th>
                  <th>
                      
                      '

                         .$data['Name'].
                     '
                  </th>
                                    <th>
                      
                      '

                         .$data['phone'].
                     '
                  </th>
                  <th>
                      
                  '

                     .$data['Gender'].
                 '
              </th>
              <th>
                      
              '

                 .$data['Email'].
             '
          </th>
          <th>
                      
          '

             .$data_app['Date'].
         '
      </th>

                  <th>';
                      
                      foreach( $Prescription_data AS $status){
                       $st=$status['status'];
                      }
                      if($Prescription_data->rowCount()===0){

                      }else{echo $st;} '
                     

                  </th>
                </tr>';
   
  }
}
    }
}else{

     echo'          <table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align: center;">
     <tr style="background-color:white;color:#021f73;">
       <th>
         ID
       </th>
       <th>
         Name
       </th>
       <th>
         Phone
       </th>
       <th>
         Gender
       </th>
       <th>
         Email
       </th>
       <th>
         Appointment
       </th>

       <th>
       Diagnosis
       </th>
     </tr>  ';  
  $search=$database->prepare("SELECT * FROM pateint");
  $search->execute();

  foreach($search AS $data){
  $Prescription_data=$database->prepare("SELECT * FROM prescription WHERE PAT_id LIKE :value");
  $Prescription_data->bindParam("value",$data['PAT_id']);
  $Prescription_data->execute();
  foreach( $Prescription_data AS $status){
    $app=$database->prepare("SELECT * FROM appointment WHERE PAT_id LIKE :value");
    $app_Value=$data['PAT_id'];
    $app->bindParam("value",$app_Value);
    $app->execute();
    foreach($app AS $data_app){  
    echo'<tr> </th><th>'.$data['PAT_id'].'</th><th>'.$data['Name'].'</th><th>'.$data['phone'].'</th><th>'.$data['Gender'].'</th><th>'.$data['Email'].'</th><th>'.$data_app['Date'].'</th><th>'.$status['status'].'</th></tr>';



}
}

}
}
    
  
    
                  
?>

         
</table>
<script src="linkBootstrap.js"></script>
</body>
</html>