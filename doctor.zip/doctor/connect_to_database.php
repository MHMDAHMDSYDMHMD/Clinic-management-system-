
<?php
  $username="root";
  $password="";
  $database=new PDO("mysql:host=localhost; dbname=clinic_managament_system;",$username ,$password);

?>