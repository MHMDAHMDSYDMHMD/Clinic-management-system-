<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>Calendar App</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>

.action .profile{
      position: relative;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer; 
      left:300px; 
      top:7px;   
  }
  
  .action .profile img{
      position: absolute;
      top: 0;
      left: 0;
      width: 75%;
      height: 75%;
      object-fit: cover;
   
     
  }
  .action .menu{
      position: absolute;
      top: 20px;
      right: 10px;
      padding: 10px;
      background-color: #fff;
      width: 200px;
      box-sizing: 0 5px 25px rgba(0,0,0,0.1);
      border-radius: 15px;
      transition: 0.9s;
      visibility: hidden;
      opacity: 0;
  }
  
  .action .menu::before{
    content: '';
    position: absolute;
    top: 0;
    left: 160px;
    height: 20px;
    width: 20px;
    background-color: #fff;
    transform: rotate(45deg);
  }
  .action .menu ul li{
    list-style: none;
    padding: 10px 0;
    border-top: 1px solid rgba(0,0,0,0.05);
    display: flex;
    align-items: center;
  }
  
  .action .menu ul li img{
    max-width: 20px;
    margin-right: 20px;
    opacity: 0.5;
    transition: 0.5s;
  }
  
  .action .menu ul li:hover img{
    opacity: 1;
  }
  
  .action .menu ul li a{
    display: inline-block;
    text-decoration: none;
    color: #5555;
    font-weight: 500;
    transition: 0.5s;
  }
  
  .action .menu ul li:hover a{
    color: #0077b6;
  }
  
  .action .menu h3{
    width: 100%;
    text-align: center;
    font-size:18px;
    font-family: Cairo;
    padding: 20px 0;
    font-weight: 500;
    color: #03035e;
    line-height: 1.2em;
  }
  .action .menu h3 span{
    font-size: 18px;
    color: #0077b6;
    font-weight: 400;
  }
  
  .action .menu.active{
    top: 80px;
    visibility: visible;
    opacity: 1;
    
  }

  .menu3 li {
    border: 2px solid transparent;
    border-bottom: 2px solid #ffffff;
    margin-right: 0px;
    padding-right: 30px;
    transition: border 0.3s ease;
  }
  
  .menu3 li:hover {
    border-top: 2px solid #ffffff;
    border-left: 2px solid #ffffff;
    border-right: 2px solid #ffffff;
    border-bottom: 2px solid transparent;
    
  }










    .searchbar{
    margin-bottom: auto;
    margin-top: -70px;
    height: 60px;
    background-color: #ffffff;
    border-radius: 30px;
    padding: 10px;
  margin-left : 280px;
      }

    .search_input{
    color: #03035e;
    border: 0;
    outline: 0;
    background: none;
    width: 650px;
    caret-color:transparent;
    line-height: 40px;
    transition: width 0.4s linear;
    }

    .searchbar:hover > .search_input{

    caret-color:#0077b6;

    }

    .searchbar:hover > .search_icon{
    background: #03035e;
    color: white;
    }

    .search_icon{
    height: 40px;
    width: 40px;
    float: right;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50%;
    border-color:#03035e;
    color:#03035e;
    text-decoration:none;

    }





input[type="date"]::-webkit-calendar-picker-indicator {
    color: rgba(0, 0, 0, 0);
    opacity: 1;
    display: block;
    background: url('GFX-MWA-Parks-Reservations.png') no-repeat;
    width: 20px;
    height: 20px;
    border-width: thin;
    position: relative;
    left: -530px;
    margin-top:7px;
}










/* filter */

ul {
    background-color: transparent;
}

ul li {
   list-style: none;
   font-size: 18px;
}

ul li button {
    font-size: inherit;
    border: none;
    background-color: transparent;
    cursor: pointer;
    width: 100%;
}

ul li button {
   display: block;
   color: inherit;
   text-decoration: none;
}

ul li a, ul li button {
  padding: 0.7rem 1rem;
  text-align: left;
}

li{
    color:#fff;
   
}

.menus {
  position: absolute;
  top: 3.2rem;
  left: 0;
  right: 0;

  margin-top:-60px;
  margin-left:130px;
  /*  hide dropdown on small screens  */
  visibility: hidden;
  /*  smooth transitioning  */
  transform: translateY(-1em);
  transition: transform ease 0.2s;
}

/* toggle main dropdown */



.dropdown {
  padding: 2px 1.5rem;
  height: 0;
  overflow: hidden;
  transition: height ease 0.2s;
}

li:focus-within .dropdown {
  height: 135px;
}

.arrow {
  width: 0.5em;
  height: 0.5em;
  display: inline-block;
  vertical-align: middle;
  border-left: 0.15em solid currentColor;
  border-bottom: 0.15em solid currentColor;
  transform: rotate(-45deg);
  margin-left: 0.38em;
  margin-top: -0.25em;
  transition: transform 100ms ease-in-out;
}

li:focus-within > button > .arrow {
  transform: rotate(-225deg);
  margin-top: 4px;
}

/* MEDIA QUERIES  */
@media (min-width: 640px) {
  
  .header-content {
    display: flex;
  }
  
  .menus {
    position: static;
    visibility: visible;
    display: flex;
    transform: initial;
  }
  

  
  ul li {
    position: relative;
    font-size: 14px;
  }
  

  
  .dropdown {
    position: absolute;
    right:0px;
    left: auto;
    box-shadow: 0 10px 15px -3px rgba(46, 41, 51, 0.08),
    0 4px 6px -2px rgba(71, 63, 79, 0.16);
    z-index: 99;
    min-width: 10rem;
    padding: 0;
    background-color: transparent;
    border-radius: 0 0 0.5rem 0.5rem; 
    width: 60px;
  }
  
  ul li:hover .dropdown {
    height: 135px;
  }
  
  ul li:hover > button > .arrow {
    transform: rotate(-225deg);
    margin-top: 4px;
  }
}


 li button:hover{
    color:#03035e;
    background:#fff;
}










  
  </style>
  
  
      <link rel="stylesheet" href="css/style.css">
      <link href="linkBootstrap.css"rel="stylesheet">
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

  
</head>

<body style="background: linear-gradient(to left,#03035e,#0077b6">
<?php

include('..\connect_to_database.php');
?>

<nav  style="background: linear-gradient(to left,#03035e,#0077b6">
        <ul class="nav justify-content-center menu3" >
      
      
            <li class="nav-item ">
              <a class="nav-link " href="..\doctorHome\DocHome.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;" >Doctor Home</a>  
            </li>
      
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\Appointment\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Appointment</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\prescription\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; ">Prescription</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\pateint\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Patient</a> 
            </li>
            <div class="action">
              <div class="profile"  >
                <img src="icon-6007530__340.png" onclick="menuToggle();" >
                </div>
<?php
                    $data=$database->prepare("SELECT * FROM `doctor` ");
                    $data->execute();
                    foreach($data AS $select){
                    } 

                    echo'
            <div class="menu">
              <h3>
                Dr/'
                .$select['Name'].
                '<br>
                <span>
                  Doctor in '
                  .$select['Specialization'].
              '</span>';
              ?>
              </h3>
              <ul>
                <li>
                  <img src="client+person+photo+picture+profile+user+icon-1320184631024101186.png" >
                  <a href="..\Account\index.php">My Profile</a>
                </li>
                <li>
                  <img src="736670-200.png">
                  <a href="..\signup\index.php">Signup</a>
                </li>
                <li>
                  <img src="free-user-logout-icon-3056-thumb.png">
                  <a href="..\mainHome\index.html">Logout</a>
                </li>
      
                
              </ul>
            </div>
          </div>
  


    </ul>
  
  </nav>

  <center>
<div style="margin-right:300px;margin-top:100px;" >

 <img src="timing-and-project-scheduling-vector-35580108-removebg-preview.png" style="width:600px; margin-left:280px; margin-top:-80px;"> 

<form method="GET">
<div class="container h-100">
      <div class="d-flex justify-content-center h-100">
        <span class="searchbar">
          <input class="search_input" name="search" placeholder="Appointment....." type="Date" >
          <button class="search_icon" name="btn-search"><i class="fas fa-search"></i></button>

        </span>
      </div>

     
    </div>
          </form>

</div>
<div id="gg">
<ul class="menus">
          <li>
            <div class="dd"
              type="button" 
              aria-haspopup="true" 
              aria-expanded="true" 
              aria-controls="dropdown1"  
            >
          <span style="color:white;font-size:20px;"> Filter <span class="arrow" style="color:white;"></span>   </span>
                </div>
            <ul class="dropdown" id="dropdown1">
                <form method="POST">
            <li><button name="ALL">ALL</button></li>
              <li><button name="Today">Today</button></li> 
              <li><button name="Expired">Expired</button></li>
                </form>
            </ul>
          </li>
        </ul>
                </div>

<script>
    function menuToggle(){
      const ToggleMenu=document.querySelector('.menu');
      ToggleMenu.classList.toggle('active');
    }
    </script>








            <?php
 if(isset($_GET['btn-search'])){

  $search=$database->prepare("SELECT * FROM appointment WHERE Date LIKE :value");
  $search_Value="%".$_GET['search']."%";
  $search->bindParam("value",$search_Value);
  $search->execute();
  foreach($search AS $data){
  $id="%".$data['PAT_id']."%";

  $Prescription_data=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
 $Prescription_data->bindParam("value",$data['PAT_id']);
  $Prescription_data->execute();

}
    if($search->rowCount()===0){
      echo '<div class="alert alert-primary d-flex align-items-center" role="alert" style="margin-top:15px; width:750px;">
      
      <div >
        <strong>No Appointment!!!</strong>

        </div>
        
    </div>';

    }else{
      echo'<table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align:center;width:1200px;color:white;">
      <tr style="background-color:white;color:#021f73;">
        <th>
          ID
        </th>
        <th>
          Time
        </th>
        <th>
          Date
        </th>
        <th>
          Price
        </th>
        <th>
          satus
        </th>
        <th>
          Patient Name
        </th>


      </tr>  ';
      $search=$database->prepare("SELECT * FROM appointment WHERE Date LIKE :value");
      $search_Value="%".$_GET['search']."%";
      $search->bindParam("value",$search_Value);
      $search->execute();
      foreach($search AS $data){
      $id="%".$data['PAT_id']."%"; 
      $app=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
      $app->bindParam("value",$data['PAT_id']);
       $app->execute();
        foreach($app AS $data_app){        
        echo'
                <tr >
                  <th>
                      '

                          .$data['APP_id'].
                      '
                  </th>
                  <th>
                      
                      '

                         .$data['Time'].
                     '
                  </th>
                                    <th>
                      
                      '

                         .$data['Date'].
                     '
                  </th>
                  <th>
                      
                  '

                     .$data['Price'].
                 '
              </th>
              <th>
                      
              '

                 .$data['status'].
             '
          </th>
              <th>
                      
              '

                 .$data_app['Name'].
             '
          </th>';
                      

  }
}
}
 }
else if(isset($_POST['Expired'])){
        
        echo '<table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align:center;width:1200px;color:white;">
        <tr style="background-color:white;color:#021f73;">
        <th>
        ID
        </th>
        <th>
        Time
        </th>
        <th>
        Date
        </th>
        <th>
        Price
        </th>
        <th>
        satus
        </th>
        <th>
        Patient Name
        </th>
        
        
        </tr>  ';
        
        $search=$database->prepare("SELECT * FROM appointment WHERE status LIKE 'expired' ");
        $search->execute();
        foreach($search AS $data){
            $id="%".$data['PAT_id']."%"; 
            $app=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
            $app->bindParam("value",$data['PAT_id']);
            $app->execute();
            foreach($app AS $data_app){      
                echo'<tr> </th><th>'.$data['APP_id'].'</th><th>'.$data['Time'].'</th><th>'.$data['Date'].'</th><th>'.$data['Price'].'</th><th>'.$data['status'].'</th><th>'.$data_app['Name'].'</th></tr>';
                
                
                
            }
        }
        
    }
    else if(isset($_POST['Today'])){
        
        echo '<table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align:center;width:1200px;color:white;">
        <tr style="background-color:white;color:#021f73;">
        <th>
        ID
        </th>
        <th>
        Time
        </th>
        <th>
        Date
        </th>
        <th>
        Price
        </th>
        <th>
        satus
        </th>
        <th>
        Patient Name
        </th>
        
        
        </tr>  ';
        
        $search=$database->prepare("SELECT * FROM appointment WHERE  DATE(Date) = CURDATE() ");
        $search->execute();
        foreach($search AS $data){
            $id="%".$data['PAT_id']."%"; 
            $app=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
            $app->bindParam("value",$data['PAT_id']);
            $app->execute();
            foreach($app AS $data_app){      
                echo'<tr> </th><th>'.$data['APP_id'].'</th><th>'.$data['Time'].'</th><th>'.$data['Date'].'</th><th>'.$data['Price'].'</th><th>'.$data['status'].'</th><th>'.$data_app['Name'].'</th></tr>';
                
                
                
            }
        }
        
    }
    else if(isset($_POST['ALL'])){
        
        echo '<table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align:center;width:1200px;color:white;">
        <tr style="background-color:white;color:#021f73;">
        <th>
        ID
        </th>
        <th>
        Time
        </th>
        <th>
        Date
        </th>
        <th>
        Price
        </th>
        <th>
        satus
        </th>
        <th>
        Patient Name
        </th>
        
        
        </tr>  ';
        
        $search=$database->prepare("SELECT * FROM appointment ");
        $search->execute();
        foreach($search AS $data){
            $id="%".$data['PAT_id']."%"; 
            $app=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
            $app->bindParam("value",$data['PAT_id']);
            $app->execute();
            foreach($app AS $data_app){      
                echo'<tr> </th><th>'.$data['APP_id'].'</th><th>'.$data['Time'].'</th><th>'.$data['Date'].'</th><th>'.$data['Price'].'</th><th>'.$data['status'].'</th><th>'.$data_app['Name'].'</th></tr>';
                
                
                
            }
        }
        
    }
else{

  echo '<table class="table table-bordered" class="form-control" style=" margin-top: 40px; text-align:center;width:1200px;color:white;">
  <tr style="background-color:white;color:#021f73;">
    <th>
      ID
    </th>
    <th>
      Time
    </th>
    <th>
      Date
    </th>
    <th>
      Price
    </th>
    <th>
      satus
    </th>
    <th>
      Patient Name
    </th>


  </tr>  ';
       
  $search=$database->prepare("SELECT * FROM appointment ");
  $search->execute();
  foreach($search AS $data){
  $id="%".$data['PAT_id']."%"; 
  $app=$database->prepare("SELECT * FROM pateint WHERE PAT_id LIKE :value");
  $app->bindParam("value",$data['PAT_id']);
   $app->execute();
    foreach($app AS $data_app){      
    echo'<tr> </th><th>'.$data['APP_id'].'</th><th>'.$data['Time'].'</th><th>'.$data['Date'].'</th><th>'.$data['Price'].'</th><th>'.$data['status'].'</th><th>'.$data_app['Name'].'</th></tr>';



}
}

}
    

    
  
    
                  
?>

         
</table>
</center>
    <script src="js/index.js"></script>

</body>
</html>
