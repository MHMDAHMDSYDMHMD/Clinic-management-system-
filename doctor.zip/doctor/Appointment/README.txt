A Pen created at CodePen.io. You can find this one at http://codepen.io/ovdojoey/pen/GqRxYQ.

 This is a calendar application.  It allows for browsing dates and selecting individual dates.   You can schedule events on future days.