<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
.menu3 li {
border: 2px solid transparent;
border-bottom: 2px solid #ffffff;
margin-right: 0px;
padding-right: 30px;
transition: border 0.3s ease;
}

.menu3 li:hover {
border-top: 2px solid #ffffff;
border-left: 2px solid #ffffff;
border-right: 2px solid #ffffff;
border-bottom: 2px solid transparent;
}
.button {
font-family: cairo;
display: inline-block;
border-radius: 4px;
background-color: rgb(255,0,0,0);
border-color: #ffffff;
color: #ffffff;
text-align: center;
font-size: 28px;

width: 15;
transition: all 0.5s;
cursor: pointer;

border-color: #ffffff;
height: 40px;
margin-left: 250px;
margin-top: -20px;
}

.button span {
cursor: pointer;
display: inline-block;
position: relative;
transition: 0.5s;

}

.button span:after {
content: '\00bb';
position: absolute;
opacity: 0;
top: 0;
right: -20px;
transition: 0.5s;
}

.button:hover span {
padding-right: 25px;
}

.button:hover span:after {
opacity: 1;
right: 0;
}
.wpcf7-date:before {
color: #b68644;
background: none;
}


*{
margin: 0;
padding: 0;
font-family: Cairo;
}
.action{
position: fixed;
top: 10px;
right: 20px;
}

.action .profile{
position: relative;
width: 60px;
height: 60px;
border-radius: 50%;
overflow: hidden;
cursor: pointer;
}

.action .profile img{
position: absolute;
top: 0;
left: 0;
width: 75%;
height: 75%;
object-fit: cover;
}
.action .menu{
position: absolute;
top: 20px;
right: 0;
padding: 10px;
background-color: #fff;
width: 200px;
box-sizing: 0 5px 25px rgba(0,0,0,0.1);
border-radius: 15px;
transition: 0.9s;
visibility: hidden;
opacity: 0;
}

.action .menu::before{
content: '';
position: absolute;
top: 0;
left: 160px;
height: 20px;
width: 20px;
background-color: #fff;
transform: rotate(45deg);
}
.action .menu ul li{
list-style: none;
padding: 10px 0;
border-top: 1px solid rgba(0,0,0,0.05);
display: flex;
align-items: center;
}

.action .menu ul li img{
max-width: 20px;
margin-right: 20px;
opacity: 0.5;
transition: 0.5s;
}

.action .menu ul li:hover img{
opacity: 1;
}

.action .menu ul li a{
display: inline-block;
text-decoration: none;
color: #5555;
font-weight: 500;
transition: 0.5s;
}

.action .menu ul li:hover a{
color: #0077b6;
}

.action .menu h3{
width: 100%;
text-align: center;
font-size:18px;
font-family: Cairo;
padding: 20px 0;
font-weight: 500;
color: #03035e;
line-height: 1.2em;
}
.action .menu h3 span{
font-size: 18px;
color: #0077b6;
font-weight: 400;
}
.action .menu.active
{
top: 80px;
visibility: visible;
opacity: 1;
}

</style>
      
          <link href="linkBootstrap.css"rel="stylesheet">
</head>
<body style="background: linear-gradient(to right,#03035e,#0077b6">

<?php
  include('..\connect_to_database.php');
?>
    <nav style="background: linear-gradient(to right,#03035e,#0077b6;margin-bottom: 60px;">
        <ul class="nav justify-content-center menu3" >
      
      
            <li class="nav-item ">
        <a class="nav-link " href="..\doctorHome\DocHome.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;  " >Doctor Home</a>  
            </li>
      
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\Appointment\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Appointment</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\prescription\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Prescription</a> 
            </li>
            <li class="nav-item ">
                <a class="nav-link " href="..\pateint\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; ">Patient</a> 
            </li>
            <div class="action">
              <div class="profile" >
                <img src="icon-6007530__340.png" onclick="menuToggle();" >
                </div>
                <?php
                
                 $data=$database->prepare("SELECT * FROM `doctor` ");
                 $data->execute();
                 foreach($data AS $select){
                 } 

                 echo'
         <div class="menu">
           <h3>
             Dr/'
             .$select['Name'].
             '<br>
             <span>
               Doctor in '
               .$select['Specialization'].
           '</span>
                  </h3>
                  <ul>
                    <li>
                      <img src="client+person+photo+picture+profile+user+icon-1320184631024101186.png" >
                      <a href="..\Account\index.php">My Profile</a>
                    </li>
                    <li>
                      <img src="736670-200.png">
                      <a href="..\signup\index.php">Signup</a>
                    </li>
                    <li>
                      <img src="free-user-logout-icon-3056-thumb.png">
                      <a href="..\mainHome\index.html">Logout</a>
                    </li>
          
                      
                  </ul>
                </div>
              </div>'
              ?>
              <script>
                  function menuToggle(){
                    const ToggleMenu=document.querySelector('.menu');
                    ToggleMenu.classList.toggle('active');
                  }
                </script>
      
        </ul>
      
      </nav> 
      

<div >

    <table  style=" margin-left: 20px; margin-top: 80px;margin-bottom: 40px;">
       <tr style="margin-top: 50px;">
           <td >
               <div id="img-prescription" style="  background-color: #ffffff;width: 550px;height: 740px;" class="form-control">              
               <span>
                
                <img src="bluelogo-removebg-preview.png" style="width: 80px;">
                <h2 style="font-family:Fantasy; margin-left: 10px;color: #0077b6;">
                    IMRA
                </h2>
                <hr style="border-width:5px;">
                <?php
                 $data=$database->prepare("SELECT * FROM `doctor` ");
                 $data->execute();
                 foreach($data AS $select){
                 } 
                echo'<h4 style="font-family: cairo; color: #03035e;margin-left: 10px;">
                DR / '.$select['Name'].
                  
                '</h4>';
                ?>
              
               

           <?php
 

if(isset($_POST['send'])){
  $Patient=$database->prepare("SELECT * From pateint WHERE Name LIKE :value");
  $Patient->bindParam("value",$_POST['Name']);
  $Patient->execute();
  foreach($Patient AS $pat_id){
  $select_app_id=$database->prepare("SELECT * From appointment WHERE PAT_id LIKE :value");
  $select_app_id->bindParam("value",$pat_id['PAT_id']);
  $select_app_id->execute();
  foreach($select_app_id AS $app_id){
    $prescript=$database->prepare("INSERT INTO prescription (Medicine_Times,status,Medicine,PAT_id,APP_id)
    VALUES(:Medidine_Time,:status,:Medicine,:PAT_id,:APP_id)");
    $status=$_POST['status'];
    $medicine=$_POST['medicine'];
    $medicine_time=$_POST['medicine_time'];
    $prescript->bindparam('Medidine_Time',$medicine_time);    
      $prescript->bindparam('Medicine',$medicine);
      $prescript->bindparam('status',$status);
    $prescript->bindparam('PAT_id',$pat_id['PAT_id']);
    $prescript->bindparam('APP_id',$app_id['APP_id']);
    $prescript->execute();
  }

  }

  

  }


    ?>

<!-- $status=$_POST['status'];
    $medicine=$_POST['medicine'];
    $medicine_time=$_POST['medicine_time'];
    $prescript=$database->prepare("INSERT INTO prescription (Medicine_Times,status,Medicine,PAT_id,APP_id)
    VALUES(Medidine_Time,status,Medicine,1,1)");

  $search=$database->prepare("SELECT * FROM pateint WHERE Name LIKE :value");

  $search->bindParam("value",$_POST['name']);

  $search->execute();

  foreach($search AS $ID){
      $APPOINT=$database->prepare("SELECT * FROM appointment WHERE PAT_id LIKE :value");
      $APPOINT->bindParam("value",$ID['PAT_id']); 
      $APPOINT->execute();
foreach($APPOINT AS $APP_ID){
      //حماية الموقع من الثغرات
  
    $prescript->bindparam('PAT_id',$ID['PAT_id']);
    $prescript->bindparam('APP_id',$APP_ID['APP_id']);
    $prescript->execute();

      }
    } -->
       <form method="POST">
       <input value="" name="Name" type ="text" placeholder="Enter Patient Name....." class="form-control" style="background-color: rgba(255,0,0,0); border-color:rgba(255,0,0,0);;font-family: Cairo; font-size: 20px; width:400px;">
        <hr style="border-width:5px;">
                <h5 style="font-family: cairo;color: #03035e;margin-left: 10px; ">
                    Status:
                </h5>

                
                <input  value="" name="status" type="text" class="form-control" style=" background-color: rgba(255,0,0,0); border-color:rgba(255,0,0,0);;font-family: Cairo; font-size: 20px; width: 100%px;height: 120px; margin-bottom: 10px;">

              
                 <h5 style="font-family: cairo;color: #03035e;margin-left: 10px;">
                    Medicine:
                 </h5>
                 
                 <input  value="" name="medicine" class="form-control" style="background-color: rgba(255,0,0,0); border-color:rgba(255,0,0,0);;font-family: Cairo; font-size: 20px; width: 100%px;height: 120px; margin-bottom: 10px;">
                
                 <h5 style="font-family: cairo;color: #03035e;margin-left: 10px;">
                    Medicine Time:
                 </h5>
                 <input  value="" type="time" name="medicine_time"  class="form-control" style="background-color: rgba(255,0,0,0); border-color:rgba(255,0,0,0);;font-family: Cairo; font-size: 20px; width: 100%px;height: 120px;">
 
               </span>
            </div>

           </td>
           <td>

               <img src="Capture-removebg-preview.png" style="margin-left: 150px; width: 600px;">
           </td>
           </tr>
           </table>


               <button class="button" name="send" style="vertical-align:middle ;margin-top: 10px;"><span>Send </span></button>


</div>
  
         </form>
               

              
      
</body>
</html>