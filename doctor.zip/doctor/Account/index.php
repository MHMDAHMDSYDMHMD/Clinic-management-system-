
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>

      .list{
       background-color: rgba(255,0,0,0);
        border-color: #30305e;
        color: #30305e;
        font-family: Cairo; 
        font-size: 20px; 
        width: 200px;
      }
        .container {
          
  position: relative;
  width: 50%;


}

#data{
  background-color: #ffffff;  
   border: 1px solid;
   margin-bottom: 30px;
  padding: 10px;
  box-shadow: 5px 10px 18px #000000;
   margin-top: 140px;
   width: 700px;
    height: 660px;
}



.image {
  display: block;
  width: 75%;
  height: 250px;
  margin-top: 20px;
  margin-left: 70px;
  border-radius: 20%;
}

.overlay {

  bottom: 100%;
  left: 0;
  right: 0;
  background-color: #0077b6;
  overflow: hidden;
 width: 590px;
  height: 0;
  transition: .5s ease;
}

.container:hover .overlay {
  bottom: 0;
  height: 100%;
  right: 50px;
}

.text {
    font-family: Cairo;
  white-space: nowrap; 
  color: white;
  font-size: 50px;
  position: absolute;
  overflow: hidden;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
}

*{
    margin: 0;
    padding: 0;
    font-family: Cairo;
}
.action{
    position: fixed;
    top: 10px;
    right: 20px;
}

.action .profile{
    position: relative;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
    cursor: pointer;
}

.action .profile img{
    position: absolute;
    top: 0;
    left: 0;
    width: 75%;
    height: 75%;
    object-fit: cover;
}
.action .menu{
    position: absolute;
    top: 20px;
    right: 0;
    padding: 10px;
    background-color: #fff;
    width: 200px;
    box-sizing: 0 5px 25px rgba(0,0,0,0.1);
    border-radius: 15px;
    transition: 0.9s;
    visibility: hidden;
    opacity: 0;
}

.action .menu::before{
  content: '';
  position: absolute;
  top: 0;
  left: 160px;
  height: 20px;
  width: 20px;
  background-color: #fff;
  transform: rotate(45deg);
}
.action .menu ul li{
  list-style: none;
  padding: 10px 0;
  border-top: 1px solid rgba(0,0,0,0.05);
  display: flex;
  align-items: center;
}

.action .menu ul li img{
  max-width: 20px;
  margin-right: 20px;
  opacity: 0.5;
  transition: 0.5s;
}

.action .menu ul li:hover img{
  opacity: 1;
}

.action .menu ul li a{
  display: inline-block;
  text-decoration: none;
  color: #5555;
  font-weight: 500;
  transition: 0.5s;
}

.action .menu ul li:hover a{
  color: #0077b6;
}

.action .menu h3{
  width: 100%;
  text-align: center;
  font-size:18px;
  font-family: Cairo;
  padding: 20px 0;
  font-weight: 500;
  color: #03035e;
  line-height: 1.2em;
}
.action .menu h3 span{
  font-size: 18px;
  color: #0077b6;
  font-weight: 400;
}

.action .menu.active{
  top: 80px;
  visibility: visible;
  opacity: 1;
}

        .menu3 li {
  border: 2px solid transparent;
  border-bottom: 2px solid #ffffff;
  margin-right: 0px;
  padding-right: 30px;
  transition: border 0.3s ease;
}

.menu3 li:hover {
  border-top: 2px solid #ffffff;
  border-left: 2px solid #ffffff;
  border-right: 2px solid #ffffff;
  border-bottom: 2px solid transparent;
}
.button {
    font-family: cairo;
  display: inline-block;
  border-radius: 4px;
  background-color: rgb(255,0,0,0);
  border-color: #30305e;
  color: #30305e;
  text-align: center;
  font-size: 28px;
  
  width: 15;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
 border-color: #30305e;
 height: 40px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}



.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
.wpcf7-date:before {
    color: #b68644;
    background: none;
}

*{
  font-family: 'Times New Roman', Times, serif;
}

    </style>
     <link href="linkBootstrap.css"rel="stylesheet">


</head>
<body style="background: linear-gradient(to top,#03035e,#0077b6);">
  <nav style="background-color:#006fb0;margin-bottom: 60px;">
    <ul class="nav justify-content-center menu3" >
  
  
        <li class="nav-item ">
          <a class="nav-link " href="..\doctorHome\DocHome.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;  " >Doctor Home</a>  
        </li>
  
        </li>
        <li class="nav-item ">
            <a class="nav-link " href="..\Appointment\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;  ">Appointment</a> 
        </li>
        <li class="nav-item ">
            <a class="nav-link " href="..\prescription\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;  ">Prescription</a> 
        </li>
        <li class="nav-item ">
            <a class="nav-link " href="..\pateint\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Patient</a> 
        </li>
        <div class="action">
          <div class="profile" >
            <img src="icon-6007530__340.png" onclick="menuToggle();" >
            </div>
            <?php
            include('..\connect_to_database.php');

                    $data=$database->prepare("SELECT * FROM `doctor` ");
                    $data->execute();
                    foreach($data AS $select){
                    } 

                    echo'
            <div class="menu">
              <h3>
                Dr/'
                .$select['Name'].
                '<br>
                <span>
                  Doctor in '
                  .$select['Specialization'].
              '</span>
              </h3>
              <ul>
                <li>
                  <img src="client+person+photo+picture+profile+user+icon-1320184631024101186.png" >
                  <a href="..\Account\index.php">My Profile</a>
                </li>
                <li>
                  <img src="736670-200.png">
                  <a href="..\signup\index.php">Signup</a>
                </li>
                <li>
                  <img src="free-user-logout-icon-3056-thumb.png">
                  <a href="..\mainHome\index.html">Logout</a>
                </li>
      
                
              </ul>
            </div>
          </div>
          <script>
            function menuToggle(){
              const ToggleMenu=document.querySelector(".menu");
              ToggleMenu.classList.toggle("active");
            }
          </script>
          
    </ul>
  
  </nav> 
  

  
<div style="height: 10px; margin-top:-100px;">

</div>
<center>
<form method="POST">
  <div id="data" class="form-control">
    <table>
      <tr>
        <th>
          <div class="container">
            <img src="i-2.jpg" class="image">
            <div class="overlay">
          </div>
        </th>
        <tr>
            <table style="width:700px;margin-top: 70px;">
              <tr style="margin-top: 20px;">
                <td>
                  <h4 style="color: #30305e;font-family: "Times New Roman", Times, serif; font-size: 35;font-weight: bold; font-style: italic;">
                    Name:
                  </h4>
                </td>
                <td>
                  

                    <input name="Name" value="'.$select["Name"].'" type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style="background-color: rgba(255,0,0,0); border-color: #30305e;color: #30305e;font-family: Cairo; font-size: 20px; width: 200px;">
            
                  
                </td>
                <td>
                  <h4 style="color: #30305e;font-family: "Times New Roman" Times, serif; font-size: 35;font-weight: bold; font-style: italic;">
                    Phone:
                  </h4>
                </td>
                <td>
                

                    <input name="phone" value="'.$select["phone"].'" type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style="background-color: rgba(255,0,0,0); border-color: #30305e;color: #30305e;font-family: Cairo; font-size: 20px; width: 200px;">
            
                  
                </td>

              </tr>
              <tr>
                <td>
                  <br>
                  <br>
                  <h4 style="color: #30305e;font-family: "Times New Roman", Times, serif; font-size: 35;font-weight: bold; font-style: italic;">
                    E-mail:
                  </h4>
                  <br>
                  <br>

                </td>
                <td>


                  <input name="Email" value="'.$select["Email"].'" type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style="background-color: rgba(255,0,0,0); border-color: #30305e;color: #30305e;font-family: Cairo; font-size: 20px; width: 200px;">
            

                </td>
                <td>
                  <h4 style="color: #30305e;font-family: "Times New Roman", Times, serif; font-size: 35;font-weight: bold; font-style: italic;">
                  Specialization:
                  </h4>
                </td>
                <td>

                    <input name="Specialization" value="'.$select["Specialization"].'" type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style="background-color: rgba(255,0,0,0); border-color: #30305e;color: #30305e;font-family: Cairo; font-size: 20px; width: 200px;">
                    

                    </td>
                    </tr>
                    </tr>
                    
                    </table>
                    
            <center>';
            
            echo'<button name="update" type="submit" value="'.$select["DOC_id"].'" class="button" style="vertical-align:middle ;margin-top: 10px;"><span>Edit </span></button>
            </center>
            
            </div>
            </tr>
            </tr>
            </table>
            </center>
            </form>';
            if(isset($_POST['update'])){
            $edit=$database->prepare("UPDATE doctor SET Name=:Name,Email=:Email,phone=:phone,Specialization=:Specialization WHERE DOC_id=:DOC_id");
            $edit->bindParam("Name",$_POST['Name']);
            $edit->bindParam("phone",$_POST['phone']);
            $edit->bindParam("Email",$_POST['Email']);
            $edit->bindParam("Specialization",$_POST['Specialization']);
            $edit->bindParam("DOC_id",$_POST['update']);
            $edit->execute();
          }




?>





</body>
</html>