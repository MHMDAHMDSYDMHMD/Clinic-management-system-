
<!DOCTYPE html>
<html>
	
<head>
	<title>
		
	</title>
  

<style>

#wave{
    height: 650px;
    width: 100%;
    margin-top: -30px;

}

.menu3 li {
border: 2px solid transparent;
border-bottom: 2px solid #fff;
margin-right: 0px;
padding-right: 30px;
transition: border 0.3s ease;
}

.menu3 li:hover {
border-top: 2px solid #fff;
border-left: 2px solid #fff;
border-right: 2px solid #fff;
border-bottom: 2px solid transparent;
}

*{

font-family: Cairo;
}
.action{
position: fixed;
top: 10px;
right: 20px;
}

.action .profile{
position: relative;
width: 60px;
height: 60px;
border-radius: 50%;
overflow: hidden;
cursor: pointer;
}

.action .profile img{
position: absolute;
top: 0;
left: 0;
width: 75%;
height: 75%;
object-fit: cover;
}
.action .menu{
position: absolute;
top: 20px;
right: 0;
padding: 10px;
background-color: #fff;
width: 200px;
box-sizing: 0 5px 25px rgba(0,0,0,0.1);
border-radius: 15px;
transition: 0.9s;
visibility: hidden;
opacity: 0;
}

.action .menu::before{
content: '';
position: absolute;
top: 0;
left: 160px;
height: 20px;
width: 20px;
background-color: #fff;
transform: rotate(45deg);
}
.action .menu ul li{
list-style: none;
padding: 10px 0;
border-top: 1px solid rgba(0,0,0,0.05);
display: flex;
align-items: center;
}

.action .menu ul li img{
max-width: 20px;
margin-right: 20px;
opacity: 0.5;
transition: 0.5s;
}

.action .menu ul li:hover img{
opacity: 1;
}

.action .menu ul li a{
display: inline-block;
text-decoration: none;
color: #5555;
font-weight: 500;
transition: 0.5s;
}

.action .menu ul li:hover a{
color: #0077b6;
}

.action .menu h3{
width: 100%;
text-align: center;
font-size:18px;
font-family: Cairo;
padding: 20px 0;
font-weight: 500;
color: #03035e;
line-height: 1.2em;
}
.action .menu h3 span{
font-size: 18px;
color: #0077b6;
font-weight: 400;
}

.action .menu.active{
top: 80px;
visibility: visible;
opacity: 1;
}





</style>
    <link href="welcome.css" rel="stylesheet">
     <link href="linkBootstrap.css"rel="stylesheet">
</head>

<body style="background-color: #FFF5E2;">
<?php
 include('..\connect_to_database.php');
      $Name=$database->prepare("SELECT * FROM `doctor` ");
      $Name->execute();
      foreach($Name AS $select){
      } 
  echo'
	<div>
        <svg id="wave" style="  transform:rotate(180deg); transition: 0.3s" viewBox="0 0 1440 490" version="1.1" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="sw-gradient-0" x1="0" x2="0" y1="1" y2="0"><stop stop-color="#0077b6" offset="0%"></stop><stop stop-color="#03045e" offset="100%"></stop></linearGradient></defs><path style="transform:translate(0, 0px); opacity:1" fill="url(#sw-gradient-0)" d="M0,49L48,49C96,49,192,49,288,81.7C384,114,480,180,576,212.3C672,245,768,245,864,212.3C960,180,1056,114,1152,81.7C1248,49,1344,49,1440,73.5C1536,98,1632,147,1728,163.3C1824,180,1920,163,2016,204.2C2112,245,2208,343,2304,326.7C2400,310,2496,180,2592,138.8C2688,98,2784,147,2880,179.7C2976,212,3072,229,3168,261.3C3264,294,3360,343,3456,302.2C3552,261,3648,131,3744,89.8C3840,49,3936,98,4032,155.2C4128,212,4224,278,4320,261.3C4416,245,4512,147,4608,114.3C4704,82,4800,114,4896,171.5C4992,229,5088,310,5184,359.3C5280,408,5376,425,5472,367.5C5568,310,5664,180,5760,155.2C5856,131,5952,212,6048,204.2C6144,196,6240,98,6336,98C6432,98,6528,196,6624,261.3C6720,327,6816,359,6864,375.7L6912,392L6912,490L6864,490C6816,490,6720,490,6624,490C6528,490,6432,490,6336,490C6240,490,6144,490,6048,490C5952,490,5856,490,5760,490C5664,490,5568,490,5472,490C5376,490,5280,490,5184,490C5088,490,4992,490,4896,490C4800,490,4704,490,4608,490C4512,490,4416,490,4320,490C4224,490,4128,490,4032,490C3936,490,3840,490,3744,490C3648,490,3552,490,3456,490C3360,490,3264,490,3168,490C3072,490,2976,490,2880,490C2784,490,2688,490,2592,490C2496,490,2400,490,2304,490C2208,490,2112,490,2016,490C1920,490,1824,490,1728,490C1632,490,1536,490,1440,490C1344,490,1248,490,1152,490C1056,490,960,490,864,490C768,490,672,490,576,490C480,490,384,490,288,490C192,490,96,490,48,490L0,490Z"></path><defs><linearGradient id="sw-gradient-1" x1="0" x2="0" y1="1" y2="0"><stop stop-color="#03045e" offset="0%"></stop><stop stop-color="#0077b6" offset="100%"></stop></linearGradient></defs><path style="transform:translate(0, 50px); opacity:0.9" fill="url(#sw-gradient-1)" d="M0,98L48,114.3C96,131,192,163,288,171.5C384,180,480,163,576,130.7C672,98,768,49,864,49C960,49,1056,98,1152,106.2C1248,114,1344,82,1440,65.3C1536,49,1632,49,1728,73.5C1824,98,1920,147,2016,187.8C2112,229,2208,261,2304,294C2400,327,2496,359,2592,343C2688,327,2784,261,2880,212.3C2976,163,3072,131,3168,114.3C3264,98,3360,98,3456,122.5C3552,147,3648,196,3744,236.8C3840,278,3936,310,4032,318.5C4128,327,4224,310,4320,318.5C4416,327,4512,359,4608,343C4704,327,4800,261,4896,269.5C4992,278,5088,359,5184,359.3C5280,359,5376,278,5472,220.5C5568,163,5664,131,5760,114.3C5856,98,5952,98,6048,114.3C6144,131,6240,163,6336,187.8C6432,212,6528,229,6624,212.3C6720,196,6816,147,6864,122.5L6912,98L6912,490L6864,490C6816,490,6720,490,6624,490C6528,490,6432,490,6336,490C6240,490,6144,490,6048,490C5952,490,5856,490,5760,490C5664,490,5568,490,5472,490C5376,490,5280,490,5184,490C5088,490,4992,490,4896,490C4800,490,4704,490,4608,490C4512,490,4416,490,4320,490C4224,490,4128,490,4032,490C3936,490,3840,490,3744,490C3648,490,3552,490,3456,490C3360,490,3264,490,3168,490C3072,490,2976,490,2880,490C2784,490,2688,490,2592,490C2496,490,2400,490,2304,490C2208,490,2112,490,2016,490C1920,490,1824,490,1728,490C1632,490,1536,490,1440,490C1344,490,1248,490,1152,490C1056,490,960,490,864,490C768,490,672,490,576,490C480,490,384,490,288,490C192,490,96,490,48,490L0,490Z"></path>Welcome</svg>

        <nav class="fixed-top" style="background-color: #021b70;">
  <ul class="nav justify-content-center menu3" >
      <li class="nav-item ">
        <a class="nav-link " href="DocHome.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px; ">Doctor Home</a>  
      </li>

      </li>
      <li class="nav-item ">
          <a class="nav-link " href="..\Appointment\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Appointment</a> 
      </li>
      <li class="nav-item ">
          <a class="nav-link " href="..\prescription\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Prescription</a> 
      </li>
      <li class="nav-item ">
          <a class="nav-link " href="..\pateint\index.php" style="color: #FFF5E2; font-family: cairo; font-size: 20px;">Patient</a> 
      </li>
      <div class="action">
        <div class="profile" >
          <img src="icon-6007530__340.png" onclick="menuToggle();" >
          </div>
          <div class="menu">
            <h3>
              Dr/'.$select['Name'].
              '<br>
              <span>
                Doctor in '.$select['Specialization'].
              '</span>
            </h3>
            <ul>
              <li>
                <img src="client+person+photo+picture+profile+user+icon-1320184631024101186.png" >
                <a href="..\Account\index.php">My Profile</a>
              </li>
              <li>
                <img src="736670-200.png">
                <a href="..\signup\index.php">Signup</a>
              </li>
              <li>
                <img src="free-user-logout-icon-3056-thumb.png">
                <a href="..\mainHome\index.html">Logout</a>
              </li>
    
                
            </ul>
          </div>
        </div>
        <script>
            function menuToggle(){
              const ToggleMenu=document.querySelector(".menu");
              ToggleMenu.classList.toggle("active");
            }
          </script>

  </ul>

</nav> 

    </div>'
    ?>
    <?php
      $Name=$database->prepare("SELECT Name FROM `doctor` ");
      $Name->execute();
      foreach($Name AS $select){
      }  
    echo'<div class="container">
        <h1 class="text1" style="font-family:"Times New Roman", Times, serif;font-size: 70px;">
            Welcome 
        </h1>
        <h3 class="text2" style="font-family: "Times New Roman", Times, serif; font-size: 40px; ">
            Dr/'.$select["Name"].
        '</h3>
    </div>'
    ?>
   
    
    


    <script src="linkBootstrap.js"></script> 
</body>

</html>


